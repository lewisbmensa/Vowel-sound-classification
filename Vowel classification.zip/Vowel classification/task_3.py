import numpy as np
import os
import matplotlib.pyplot as plt
from print_values import *
from plot_data_all_phonemes import *
from plot_data import *
import random
from sklearn.preprocessing import normalize
from get_predictions import *
from plot_gaussians import *


# File that contains the data


data_npy_file = 'data/PB_data.npy'

# Loading data from .npy file
data = np.load(data_npy_file, allow_pickle=True)
data = np.ndarray.tolist(data)

# Make a folder to save the figures
figures_folder = os.path.join(os.getcwd(), 'figures')
if not os.path.exists(figures_folder):
    os.makedirs(figures_folder, exist_ok=True)

# Array that contains the phoneme ID (1-10) of each sample
phoneme_id = data['phoneme_id']
# frequencies f1 and f2
f1 = data['f1']
f2 = data['f2']

# Initialize array containing f1 & f2, of all phonemes.
X_full = np.zeros((len(f1), 2))
#########################################
# Write your code here
# Store f1 in the first column of X_full, and f2 in the second column of X_full
X_full[:,0] = f1
X_full[:,1] = f2
########################################/
X_full = X_full.astype(np.float32)

# number of GMM components
k = 6

#########################################
# Write your code here

# Create an array named "X_phonemes_1_2", containing only samples that belong to phoneme 1 and samples that belong to phoneme 2.


# The shape of X_phonemes_1_2 will be two-dimensional. Each row will represent a sample of the dataset, and each column will represent a feature (e.g. f1 or f2)
# Fill X_phonemes_1_2 with the samples of X_full that belong to the chosen phonemes
# To fill X_phonemes_1_2, you can leverage the phoneme_id array, that contains the ID of each sample of X_full

#initialise 2-dimensional array with the length equal to the sum of the amount of phoneme 1 and phoneme 2
X_phonemes_1_2 = np.zeros((np.sum((phoneme_id==1) | (phoneme_id== 2)),2))

#the first column is f1 in the index where the phoneme id equals to 1 or 2
X_phonemes_1_2[:,0] = f1[np.where((phoneme_id==1) |(phoneme_id==2))]

#the second column is f2 in the index where the phoneme id equal to 1 or 2
X_phonemes_1_2[:,1] = f2[np.where((phoneme_id==1)|(phoneme_id==2))]


#create a ground truth array. This is the same length as X_phonemes_1_2 but with only 1 column returning the phoneme id of each entry
ground_truth = np.zeros((np.sum((phoneme_id==1) | (phoneme_id== 2))))

#return the phoneme id at the index where the phoneme id equals 1 or 2
ground_truth = phoneme_id[np.where((phoneme_id==1) | (phoneme_id==2))]

########################################/

# Plot array containing the chosen phonemes

# Create a figure and a subplot
fig, ax1 = plt.subplots()

title_string = 'Phoneme 1 & 2'
# plot the samples of the dataset, belonging to the chosen phoneme (f1 & f2, phoneme 1 & 2)
plot_data(X=X_phonemes_1_2, title_string=title_string, ax=ax1)
# save the plotted points of phoneme 1 as a figure
plot_filename = os.path.join(os.getcwd(), 'figures', 'dataset_phonemes_1_2.png')
plt.savefig(plot_filename)


#########################################
# Write your code here
# Get predictions on samples from both phonemes 1 and 2, from a GMM with k components, pretrained on phoneme 1
# Get predictions on samples from both phonemes 1 and 2, from a GMM with k components, pretrained on phoneme 2
# Compare these predictions for each sample of the dataset, and calculate the accuracy, and store it in a scalar variable named "accuracy"

p_id = 1

#load the data for the parameters trained on X_phoneme_1
load= np.load('data/GMM_params_phoneme_{:02}_k_{:02}.npy'.format(p_id, k) ,allow_pickle= True).item()

#get the prediction for the model trained on X_phoneme_1
L= get_predictions(load['mu'],load['s'],load['p'],X_phonemes_1_2)

#initialise an array which will contain the probability of each point belonging to a certain phoneme id.
#this is the same length as X_phonemes_1_2 and is only 1 column.
prob = np.zeros(len(X_phonemes_1_2))

#create a for loop define the values of the prob variable
for i in range(len(X_phonemes_1_2)):
    prob[i] = np.sum(L[i])#every row entry in prob is given by the sum of the row of the get_predictions.

p_id = 2

#load the data for the parameters trained on X_phoneme_2
Load2 = np.load('data/GMM_params_phoneme_{:02}_k_{:02}.npy'.format(p_id, k),allow_pickle=True).item()

#get the prediction for the model trained on X_phoneme_2
L2 = get_predictions(Load2['mu'],Load2['s'],Load2['p'],X_phonemes_1_2)

#initialise an array which will contain the probability of each point belonging to a certain phoneme id.
prob2 = np.zeros(len(X_phonemes_1_2))

#create a for loop define the values of the prob2 variable
for i in range(len(X_phonemes_1_2)):
    prob2[i] = np.sum(L2[i])#every row entry in prob2 is given by the sum of the row of the get_predictions.


#create a variable classifier that returns whether or not each entry belongs to phoneme id 1 or 2
#this will be the length of X_phonemes_1_2 and 1 column
classifier = np.zeros(len(X_phonemes_1_2))
for i in range(len((X_phonemes_1_2))):
    if prob[i]>prob2[i]:
        classifier[i] = 1 # if the probability of the point trained on the X_phoneme_1 model is larger than the probability of the point trained on the X_phoneme_2 model
        #this will label the point as phoneme id 1
    else:
        classifier[i] = 2 #this will label the point as phoneme id 2 if prob is not greater than prob 2

########################################/

#initialise a variable for accuracy
accuracy = 0.0

#create a for loop to iterate through and compare the entries of the classifier with the ground truth
for i in range(len((X_phonemes_1_2))):
    if classifier[i]==ground_truth[i]:
        accuracy = accuracy + 1 #if the entry of the classifier is equal to the entry of the ground truth then increase the count by 1.
        #this code will return the count of right predictions of our models

#to calculate percentage, we use the formula (number of correct predictions/total number of samples)*100
accuracy = (accuracy/len(X_phonemes_1_2))*100




print('Accuracy using GMMs with {} components: {:.2f}%'.format(k, accuracy))

################################################
# enter non-interactive mode of matplotlib, to keep figures open
plt.ioff()
plt.show()