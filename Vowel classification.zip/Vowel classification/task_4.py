import numpy as np
import os
import matplotlib.pyplot as plt
from print_values import *
from plot_data_all_phonemes import *
from plot_data import *
import random
from sklearn.preprocessing import normalize
from get_predictions import *
from plot_gaussians import *

# File that contains the data
data_npy_file = 'data/PB_data.npy'

# Loading data from .npy file
data = np.load(data_npy_file, allow_pickle=True)
data = np.ndarray.tolist(data)

# Make a folder to save the figures
figures_folder = os.path.join(os.getcwd(), 'figures')
if not os.path.exists(figures_folder):
    os.makedirs(figures_folder, exist_ok=True)

# Array that contains the phoneme ID (1-10) of each sample
phoneme_id = data['phoneme_id']
# frequencies f1 and f2
f1 = data['f1']
f2 = data['f2']

# Initialize array containing f1 & f2, of all phonemes.
X_full = np.zeros((len(f1), 2))
#########################################
# Write your code here
# Store f1 in the first column of X_full, and f2 in the second column of X_full
X_full[:,0] = f1
X_full[:,1] = f2
########################################/
X_full = X_full.astype(np.float32)

# number of GMM components
k = 3

p_id=1
#########################################
# Write your code here

# Create an array named "X_phonemes_1_2", containing only samples that belong to phoneme 1 and samples that belong to phoneme 2.
# The shape of X_phonemes_1_2 will be two-dimensional. Each row will represent a sample of the dataset, and each column will represent a feature (e.g. f1 or f2)
# Fill X_phonemes_1_2 with the samples of X_full that belong to the chosen phonemes
# To fill X_phonemes_1_2, you can leverage the phoneme_id array, that contains the ID of each sample of X_full


#initialise 2-dimensional array with the length equal to the sum of the amount of phoneme 1
phoneme_1 = np.zeros((np.sum(phoneme_id==1), 2))

#the first column is f1 in the index where the phoneme id equal to 1
phoneme_1[:,0] = f1[np.where(phoneme_id==1)]

#the second column is f2 in the index where the phoneme id equal to 1
phoneme_1[:,1] = f2[np.where(phoneme_id==1)]

#initialise 2-dimensional array with the length equal to the sum of the amount of phoneme 2
phoneme_2 = np.zeros((np.sum(phoneme_id==2), 2))

#the first column is f1 in the index where the phoneme id equal to 2
phoneme_2[:,0] = f1[np.where(phoneme_id==2)]

#the second column is f2 in the index where the phoneme id equal to 2
phoneme_2[:,1] = f2[np.where(phoneme_id==2)]

#concatenate phoneme_1 and phoneme_2
#This way we have ordered the data such that phoneme_1 points are first, followed by all phoneme_2 points
phonemes_1_2 = np.concatenate((phoneme_1,phoneme_2))


X = phonemes_1_2.copy()


min_f1 = int(np.min(X[:,0]))
max_f1 = int(np.max(X[:,0]))
min_f2 = int(np.min(X[:,1]))
max_f2 = int(np.max(X[:,1]))
N_f1 = max_f1 - min_f1
N_f2 = max_f2 - min_f2
print('f1 range: {}-{} | {} points'.format(min_f1, max_f1, N_f1))
print('f2 range: {}-{} | {} points'.format(min_f2, max_f2, N_f2))


#########################################
# Write your code here

# Create a custom grid of shape N_f1 x N_f2
# The grid will span all the values of (f1, f2) pairs, between [min_f1, max_f1] on f1 axis, and between [min_f2, max_f2] on f2 axis
# Then, classify each point [i.e., each (f1, f2) pair] of that grid, to either phoneme 1, or phoneme 2, using the two trained GMMs
# Do predictions, using GMM trained on phoneme 1, on custom grid
# Do predictions, using GMM trained on phoneme 2, on custom grid
# Compare these predictions, to classify each point of the grid
# Store these prediction in a 2D numpy array named "M", of shape N_f2 x N_f1 (the first dimension is f2 so that we keep f2 in the vertical axis of the plot)
# M should contain "0.0" in the points that belong to phoneme 1 and "1.0" in the points that belong to phoneme 2
########################################/


nx,ny = (N_f1,N_f2)

#create an array of points f1 evenly spaced, with length N_f1
x = np.linspace(min_f1,max_f1,nx)
#create an array of points f2, evenly spaced of with length N_f2
y = np.linspace(min_f2,max_f2,ny)

#This variable will be an Nx2 array that spans all possible linear combinations of x and y.
matrix = np.transpose([np.tile(x, len(y)), np.repeat(y, len(x))])

#load the data for the parameters trained on X_phoneme_1
load= np.load('data/GMM_params_phoneme_{:02}_k_{:02}.npy'.format(p_id, k) ,allow_pickle= True).item()

#get the prediction for the model trained on X_phoneme_1
L= get_predictions(load['mu'],load['s'],load['p'],matrix)

#initialise an array which will contain the probability of each point belonging to a certain phoneme id.
#this is the same length as X_phonemes_1_2 and is only 1 column.
prob = np.zeros(len(matrix))

#create a for loop define the values of the prob variable
for i in range(len(matrix)):
    prob[i] = np.sum(L[i])#every row entry in prob is given by the sum of the row of the get_predictions.

p_id = 2

#load the data for the parameters trained on X_phoneme_2
Load2 = np.load('data/GMM_params_phoneme_{:02}_k_{:02}.npy'.format(p_id, k),allow_pickle=True).item()

#get the prediction for the model trained on X_phoneme_2
L2 = get_predictions(Load2['mu'],Load2['s'],Load2['p'],matrix)

#initialise an array which will contain the probability of each point belonging to a certain phoneme id.
prob2 = np.zeros(len(matrix))

#create a for loop define the values of the prob2 variable
for i in range(len(matrix)):
    prob2[i] = np.sum(L2[i])#every row entry in prob2 is given by the sum of the row of the get_predictions.



classifier = np.zeros(len(matrix))
for i in range(len((matrix))):
    if prob[i]>prob2[i]:
        classifier[i] = 0 # if the probability of the point trained on the X_phoneme_1 model is larger than the probability of the point trained on the X_phoneme_2 model
        #this will label the point as phoneme id 1
    else:
        classifier[i] = 1

M= np.reshape(classifier,(N_f2,N_f1))

################################################
# Visualize predictions on custom grid

# Create a figure
#fig = plt.figure()
fig, ax = plt.subplots()

# use aspect='auto' (default is 'equal'), to force the plotted image to be square, when dimensions are unequal
plt.imshow(M, aspect='auto')

# set label of x axis
ax.set_xlabel('f1')
# set label of y axis
ax.set_ylabel('f2')

# set limits of axes
plt.xlim((0, N_f1))
plt.ylim((0, N_f2))

# set range and strings of ticks on axes
x_range = np.arange(0, N_f1, step=50)
x_strings = [str(x+min_f1) for x in x_range]
plt.xticks(x_range, x_strings)
y_range = np.arange(0, N_f2, step=200)
y_strings = [str(y+min_f2) for y in y_range]
plt.yticks(y_range, y_strings)

# set title of figure
title_string = 'Predictions on custom grid'
plt.title(title_string)

# add a colorbar
plt.colorbar()

N_samples = int(X.shape[0]/2)
plt.scatter(X[:N_samples, 0] - min_f1, X[:N_samples, 1] - min_f2, marker='.', color='red', label='Phoneme 1')
plt.scatter(X[N_samples:, 0] - min_f1, X[N_samples:, 1] - min_f2, marker='.', color='green', label='Phoneme 2')

# add legend to the subplot
plt.legend()

# save the plotted points of the chosen phoneme, as a figure
plot_filename = os.path.join(os.getcwd(), 'figures', 'GMM_predictions_on_grid.png')
plt.savefig(plot_filename)

################################################
# enter non-interactive mode of matplotlib, to keep figures open
plt.ioff()
plt.show()